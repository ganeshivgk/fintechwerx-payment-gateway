<?php
function handle_verify_otp() {
    $customerId = get_current_user_id();
    $merchantId = 'your_merchant_id';  // Replace this with your actual merchant ID
    $otp = $_POST['otp'];

    $response = verify_otp($customerId, $merchantId, $otp);

    echo json_encode($response);
    wp_die(); // This is required to terminate immediately and return a proper response
}

function handle_resend_otp() {
    $customerId = get_current_user_id();
    $merchantId = 'your_merchant_id';  // Replace this with your actual merchant ID
    $mobileNumber = 'your_mobile_number';  // Replace this with the user's actual mobile number

    $response = resend_otp($customerId, $merchantId, $mobileNumber);

    echo json_encode($response);
    wp_die(); // This is required to terminate immediately and return a proper response
}

add_action('wp_ajax_verify_otp', 'handle_verify_otp');
add_action('wp_ajax_nopriv_verify_otp', 'handle_verify_otp');

add_action('wp_ajax_resend_otp', 'handle_resend_otp');
add_action('wp_ajax_nopriv_resend_otp', 'handle_resend_otp');
?>
