<?php

?>
<div id="otpModalWrapper">
  <div id="otpModal" class="modal">
    <div class="modal-content">
      <h4>OTP Verification</h4>
      <form id="otp_form">
        <label for="otp">Enter the OTP:</label>
        <input type="text" id="otp" name="otp">
        <button type="button" id="verify_otp">Verify OTP</button>
        <button type="button" id="resend_otp">Resend OTP</button>
      </form>
    </div>
    <div class="modal-footer">
      <button type="button" class="modal-close">Close</button>
    </div>
  </div>
</div>

<!-- Modal CSS -->
<style>
#otpModalWrapper .modal {
  display: none;
  position: fixed;
  z-index: 1;
  padding-top: 100px;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0,0,0,0.4);
}

#otpModalWrapper .modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 50%;
}
</style>
