<?php
//wp_enqueue_script('my-ajax-script', plugin_dir_url(__FILE__) . 'js/script.js', array('jquery'));
//wp_localize_script('my-ajax-script', 'my_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
?>
