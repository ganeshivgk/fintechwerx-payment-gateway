jQuery(document).ready(function($){
    $('#verify_otp').click(function(e){
        e.preventDefault();
        var otp = $('#otp').val();
        $.ajax({
            url: my_ajax_object.ajax_url,
            type: 'POST',
            data: {
                'action': 'verify_otp',
                'otp': otp
            },
            success: function(data){
                alert(data.message);
            }
        });
    });

    $('#resend_otp').click(function(e){
        e.preventDefault();
        $.ajax({
            url: my_ajax_object.ajax_url,
            type: 'POST',
            data: {
                'action': 'resend_otp'
            },
            success: function(data){
                alert(data.message);
            }
        });
    });
});

