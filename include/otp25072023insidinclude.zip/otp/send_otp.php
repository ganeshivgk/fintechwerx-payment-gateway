<?php
function send_otp($customerId, $merchantId, $mobileNumber) {
    $url = 'https://api-qa.fintechwerx.com/2FA/authentication/sendOTP';

    $body = array(
        'customerId' => $customerId,
        'merchantId' => $merchantId,
        'mobileNumber' => $mobileNumber
    );

    $args = array(
        'body' => json_encode($body),
        'headers' => array('Content-Type' => 'application/json')
    );

    $response = wp_remote_post($url, $args);

    return json_decode(wp_remote_retrieve_body($response));
}
?>
